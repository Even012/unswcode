"""
   crown.py
   COMP9444, CSE, UNSW
"""
# Provide code for a pytorch module called Full3Net
# which implements a 3-layer fully connected neural network with two hidden layers using tanh activation,
# followed by the output layer with one node using sigmoid activation.
# Your network should have the same number of hidden nodes in each layer, specified by the variable hid.
# The hidden layer activations (after applying tanh) should be stored into self.hid1 and self.hid2 so they can be graphed afterwards.


import torch
import torch.nn as nn
import matplotlib.pyplot as plt

class Full3Net(torch.nn.Module):
    def __init__(self, hid):
        super(Full3Net, self).__init__()
        self.in_hid = torch.nn.Linear(2, hid)
        self.hid_hid = torch.nn.Linear(hid, hid)
        self.hid_out = torch.nn.Linear(hid, 1)
    def forward(self, input):
        # self.hid1 = None
        # self.hid2 = None
        first_hid_sum = self.in_hid(input)
        self.hid1 = torch.tanh(first_hid_sum)
        second_hid_sum = self.hid_hid(self.hid1)
        self.hid2 = torch.tanh(second_hid_sum)
        out_sum = self.hid_out(self.hid2)
        output = torch.sigmoid(out_sum)
        return output
        # return 0*input[:,0]

class Full4Net(torch.nn.Module):
    def __init__(self, hid):
        super(Full4Net, self).__init__()
        self.in_hid = torch.nn.Linear(2, hid)
        self.hid_hid = torch.nn.Linear(hid, hid)
        self.hid_out = torch.nn.Linear(hid, 1)

    def forward(self, input):
        first_hid_sum = self.in_hid(input)
        self.hid1 = torch.tanh(first_hid_sum)
        second_hid_sum = self.hid_hid(self.hid1)
        self.hid2 = torch.tanh(second_hid_sum)
        third_hid_sum = self.hid_hid(self.hid2)
        self.hid3 = torch.tanh(third_hid_sum)
        out_sum = self.hid_out(self.hid3)
        output = torch.sigmoid(out_sum)
        return output
        # return 0*input[:,0]

class DenseNet(torch.nn.Module):
    def __init__(self, num_hid):
        super(DenseNet, self).__init__()

    def forward(self, input):
        self.hid1 = None
        self.hid2 = None
        return 0*input[:,0]
